import { integer, primaryKey, sqliteTable, text } from "drizzle-orm/sqlite-core";

// Both keys are required in every application query. Owner comes exclusively
// from the authenticated Sites request identity, never from request JSON.
export const xunxuProfiles = sqliteTable("xunxu_profiles", {
  ownerId: text("owner_id").notNull(),
  id: text("id").notNull(),
  name: text("name").notNull(),
  dataJson: text("data_json").notNull(),
  imageKeysJson: text("image_keys_json").notNull().default("{}"),
  revision: integer("revision").notNull().default(1),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
}, (table) => [primaryKey({ columns: [table.ownerId, table.id] })]);
