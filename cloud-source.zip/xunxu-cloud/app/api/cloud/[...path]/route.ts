import { env } from "cloudflare:workers";
import { handleCloudRequest } from "../../../../lib/cloud-api.mjs";

export const dynamic = "force-dynamic";

function handle(request: Request) {
  return handleCloudRequest(request, env, undefined);
}

export const GET = handle;
export const POST = handle;
export const PUT = handle;
export const OPTIONS = handle;
