import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "循序｜云端马拉松训练计划",
  description: "按目标生成训练课表，独立云端档案保存成绩、个人资料与打卡。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
