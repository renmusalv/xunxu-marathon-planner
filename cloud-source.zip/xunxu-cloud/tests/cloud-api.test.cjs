'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { pathToFileURL } = require('node:url');
const path = require('node:path');

const api = import(pathToFileURL(path.join(__dirname, '../lib/cloud-api.mjs')).href);
const ORIGIN = 'https://planner.example.test';
const TODAY = new Date().toISOString().slice(0, 10);
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9ZlS8AAAAASUVORK5CYII=', 'base64');

class D1Memory {
  constructor() {
    this.sqlite = new DatabaseSync(':memory:');
    this.sqlite.exec(`CREATE TABLE xunxu_profiles (
      owner_id TEXT NOT NULL, id TEXT NOT NULL, name TEXT NOT NULL,
      data_json TEXT NOT NULL, image_keys_json TEXT NOT NULL DEFAULT '{}',
      revision INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL, PRIMARY KEY(owner_id,id)
    )`);
    this.beforeUpdate = null; this.afterUpdate = null;
  }
  prepare(sql) {
    const adapter = this; let args = [];
    return {
      bind(...values) { args = values; return this; },
      async first() {
        if (sql.startsWith('UPDATE') && adapter.beforeUpdate) {
          const hook = adapter.beforeUpdate; adapter.beforeUpdate = null; await hook();
        }
        const result = adapter.sqlite.prepare(sql).get(...args) || null;
        if (sql.startsWith('UPDATE') && adapter.afterUpdate) {
          const hook = adapter.afterUpdate; adapter.afterUpdate = null; await hook();
        }
        return result;
      },
      async all() { return { results: adapter.sqlite.prepare(sql).all(...args) }; },
      async run() { const result = adapter.sqlite.prepare(sql).run(...args); return { success: true, meta: { changes: Number(result.changes) } }; },
    };
  }
  row(owner, profileId) { return this.sqlite.prepare('SELECT * FROM xunxu_profiles WHERE owner_id = ? AND id = ?').get(owner, profileId); }
}
class R2Memory {
  constructor() { this.objects = new Map(); this.deleted = []; this.puts = []; this.afterPut = null; this.failAfterPut = false; this.failDeletes = 0; }
  async put(key, data, options) {
    this.objects.set(key, { bytes: new Uint8Array(data), options }); this.puts.push(key);
    if (this.afterPut) { const hook = this.afterPut; this.afterPut = null; await hook(key); }
    if (this.failAfterPut) { this.failAfterPut = false; throw new Error('simulated ambiguous R2 write'); }
  }
  async get(key) { const item = this.objects.get(key); return item ? { body: item.bytes, size: item.bytes.length, httpMetadata: item.options.httpMetadata } : null; }
  async delete(keys) {
    if (this.failDeletes > 0) { this.failDeletes--; throw new Error('temporary delete failure'); }
    for (const key of Array.isArray(keys) ? keys : [keys]) { this.objects.delete(key); this.deleted.push(key); }
  }
}
function fixture() { return { DB: new D1Memory(), BUCKET: new R2Memory() }; }
function headers(owner = 'account-a', method = 'GET') {
  return { ...(owner ? { 'oai-authenticated-user-id': owner, 'oai-authenticated-user-email': owner + '@example.test' } : {}), ...(method !== 'GET' ? { Origin: ORIGIN, 'X-Xunxu-Request': '1', 'Sec-Fetch-Site': 'same-origin' } : {}) };
}
async function request(env, route, { method = 'GET', owner = 'account-a', value, extraHeaders = {}, removeHeaders = [] } = {}) {
  const hs = { ...headers(owner, method), ...extraHeaders };
  if (value !== undefined) hs['Content-Type'] = 'application/json';
  for (const key of removeHeaders) delete hs[key];
  const req = new Request(ORIGIN + '/api/cloud/' + route, { method, headers: hs, ...(value === undefined ? {} : { body: JSON.stringify(value) }) });
  return (await api).handleCloudRequest(req, env);
}
function emptyData() { return { form: { distance: '21.0975', halfGoalTime: '01:45:00' }, records: [], plans: {}, history: [] }; }
function race(overrides = {}) {
  return { id: 'race_1', distanceKm: 10, elapsedSeconds: 3000, date: TODAY, averageHr: 155, peakHr: 180, effort: 'race', confirmed: true, include: true, durationType: 'elapsed', course: 'road_flat', source: 'screenshot', hasImage: true, ...overrides };
}
async function create(env, profileId = 'profile_1', owner = 'account-a', data = emptyData()) {
  const response = await request(env, 'profiles', { method: 'POST', owner, value: { id: profileId, name: '训练档案', data } });
  assert.equal(response.status, 201, await response.clone().text()); return (await response.json()).profile;
}
async function upload(env, profile, { owner = 'account-a', data, recordId = 'race_1', bytes = PNG, type = 'image/png', revision = profile.revision } = {}) {
  const form = new FormData();
  form.set('payload', JSON.stringify({ data: data || { ...profile.data, records: [race()] }, revision }));
  form.set('imageRecordId', recordId); form.set('image', new Blob([bytes], { type }), 'result.png');
  const req = new Request(ORIGIN + '/api/cloud/profiles/' + profile.id, { method: 'PUT', headers: headers(owner, 'PUT'), body: form });
  return (await api).handleCloudRequest(req, env);
}

test('anonymous requests are denied and JSON cannot supply an authenticated owner', async () => {
  const env = fixture();
  assert.equal((await request(env, 'session', { owner: null })).status, 401);
  assert.equal((await request(env, 'profiles', { owner: null, method: 'POST', value: { ownerId: 'account-a', id: 'forged', name: '伪造', data: emptyData() } })).status, 401);
  const created = await request(env, 'profiles', { method: 'POST', value: { ownerId: 'account-b', id: 'owned_by_a', name: '私有档案', data: emptyData() } });
  assert.equal(created.status, 201);
  assert.ok(env.DB.row('account-a', 'owned_by_a'));
  assert.equal(env.DB.row('account-b', 'owned_by_a'), undefined);
});

test('session and profile reads isolate two accounts even when profile identifiers are identical', async () => {
  const env = fixture();
  await create(env, 'same_id', 'account-a', { ...emptyData(), form: { restingHr: '48' } });
  await create(env, 'same_id', 'account-b', { ...emptyData(), form: { restingHr: '62' } });
  await create(env, 'a_private', 'account-a');
  const a = await (await request(env, 'profiles/same_id')).json();
  const b = await (await request(env, 'profiles/same_id', { owner: 'account-b' })).json();
  assert.equal(a.profile.data.form.restingHr, '48'); assert.equal(b.profile.data.form.restingHr, '62');
  const sessionB = await (await request(env, 'session', { owner: 'account-b' })).json();
  assert.deepEqual(sessionB.profiles.map(profile => profile.id), ['same_id']);
  assert.equal((await request(env, 'profiles/a_private', { owner: 'account-b' })).status, 404);
  assert.equal((await request(env, 'profiles/a_private', { method: 'PUT', owner: 'account-b', value: { data: emptyData(), revision: 1 } })).status, 404);
});

test('write requests require the custom header and a same-origin browser source', async () => {
  const env = fixture(), value = { id: 'p', name: '档案', data: emptyData() };
  for (const config of [
    { removeHeaders: ['X-Xunxu-Request'] },
    { extraHeaders: { Origin: 'https://attacker.example.test' } },
    { extraHeaders: { 'Sec-Fetch-Site': 'cross-site' } },
    { removeHeaders: ['Origin', 'Sec-Fetch-Site'] }
  ]) assert.equal((await request(env, 'profiles', { method: 'POST', value, ...config })).status, 403);
  assert.equal((await request(env, 'profiles', { method: 'POST', value, removeHeaders: ['Origin'] })).status, 201);
});

test('responses have no-store and do not expose owner identity keys or private object maps', async () => {
  const env = fixture(); await create(env);
  const response = await request(env, 'profiles/profile_1');
  assert.match(response.headers.get('Cache-Control'), /no-store/);
  assert.equal(response.headers.get('Access-Control-Allow-Origin'), null);
  assert.equal(response.headers.get('Cross-Origin-Resource-Policy'), 'same-origin');
  const result = await response.json();
  assert.deepEqual(Object.keys(result.profile).sort(), ['data', 'id', 'name', 'revision', 'updatedAt']);
  assert.ok(!JSON.stringify(result).includes('image_keys_json'));
});

test('CAS accepts one edit and rejects a stale edit without overwriting cloud data', async () => {
  const env = fixture(), profile = await create(env);
  const first = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: profile.revision, data: { ...profile.data, form: { restingHr: '51' } } } });
  assert.equal(first.status, 200); assert.equal((await first.json()).profile.revision, 2);
  const stale = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: 1, data: { ...profile.data, form: { restingHr: '99' } } } });
  assert.equal(stale.status, 409); assert.equal((await stale.json()).currentRevision, 2);
  assert.equal(JSON.parse(env.DB.row('account-a', 'profile_1').data_json).form.restingHr, '51');
});

test('multipart save atomically associates private images and isolates account/profile reads', async () => {
  const env = fixture(), profile = await create(env);
  await create(env, 'profile_2'); await create(env, 'profile_1', 'account-b');
  const savedResponse = await upload(env, profile); assert.equal(savedResponse.status, 200, await savedResponse.clone().text());
  const saved = (await savedResponse.json()).profile;
  assert.equal(saved.revision, 2); assert.equal(saved.data.records[0].hasImage, true);
  assert.equal(saved.data.records[0].profileId, 'profile_1');
  assert.ok(!JSON.stringify(saved).includes('cloud/v1/'));
  const image = await request(env, 'profiles/profile_1/images/race_1');
  assert.equal(image.status, 200); assert.equal(image.headers.get('Content-Type'), 'image/png');
  assert.match(image.headers.get('Cache-Control'), /no-store/);
  assert.deepEqual(Buffer.from(await image.arrayBuffer()), PNG);
  assert.equal((await request(env, 'profiles/profile_1/images/race_1', { owner: 'account-b' })).status, 404);
  assert.equal((await request(env, 'profiles/profile_2/images/race_1')).status, 404);
  assert.equal((await request(env, 'profiles/profile_1/images/race_1', { owner: null })).status, 401);
});

test('hasImage cannot be forged and a record cannot claim another profile', async () => {
  const env = fixture();
  const profile = await create(env, 'profile_1', 'account-a', { ...emptyData(), records: [race({ hasImage: true })] });
  assert.equal(profile.data.records[0].hasImage, false);
  const invalid = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: 1, data: { ...emptyData(), records: [race({ profileId: 'someone_else' })] } } });
  assert.equal(invalid.status, 400);
  const injectedMap = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: 1, data: { ...emptyData(), imageKeys: { race_1: 'other-account-object' } } } });
  assert.equal(injectedMap.status, 400);
});

test('replacing and deleting a record clean only its own old image after CAS success', async () => {
  const env = fixture(), profile = await create(env);
  const first = (await (await upload(env, profile)).json()).profile;
  const oldKey = env.BUCKET.puts[0];
  const second = (await (await upload(env, first, { data: first.data })).json()).profile;
  const newKey = env.BUCKET.puts[1];
  assert.notEqual(oldKey, newKey); assert.equal(env.BUCKET.objects.has(oldKey), false); assert.equal(env.BUCKET.objects.has(newKey), true);
  const removed = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: second.revision, data: { ...second.data, records: [] } } });
  assert.equal(removed.status, 200); assert.equal(env.BUCKET.objects.size, 0);
  assert.equal((await request(env, 'profiles/profile_1/images/race_1')).status, 404);
});

test('a CAS race after an image upload deletes the new object and preserves the existing image', async () => {
  const env = fixture(), profile = await create(env);
  const current = (await (await upload(env, profile)).json()).profile;
  const oldKey = env.BUCKET.puts[0];
  env.BUCKET.afterPut = async () => { env.DB.sqlite.prepare('UPDATE xunxu_profiles SET revision = revision + 1 WHERE owner_id = ? AND id = ?').run('account-a', profile.id); };
  const conflicted = await upload(env, current, { data: current.data });
  assert.equal(conflicted.status, 409); assert.equal((await conflicted.json()).currentRevision, 3);
  assert.equal(env.BUCKET.objects.has(oldKey), true);
  assert.equal(env.BUCKET.objects.has(env.BUCKET.puts[1]), false);
  assert.equal(Object.values(JSON.parse(env.DB.row('account-a', profile.id).image_keys_json))[0].key, oldKey);
});

test('a failed image write rolls back the new object and leaves profile revision unchanged', async () => {
  const env = fixture(), profile = await create(env); env.BUCKET.failAfterPut = true;
  const response = await upload(env, profile);
  assert.equal(response.status, 503); assert.equal((await response.json()).code, 'image_write_failed');
  assert.equal(env.DB.row('account-a', profile.id).revision, 1); assert.equal(env.BUCKET.objects.size, 0);
});

test('database failure before commit removes the uncommitted image', async () => {
  const env = fixture(), profile = await create(env);
  env.DB.beforeUpdate = async () => { throw new Error('database temporarily unavailable'); };
  const response = await upload(env, profile);
  assert.equal(response.status, 503); assert.equal((await response.json()).code, 'save_uncertain');
  assert.equal(env.DB.row('account-a', profile.id).revision, 1); assert.equal(env.BUCKET.objects.size, 0);
});

test('an ambiguous database error after commit preserves the referenced image and returns the saved state', async () => {
  const env = fixture(), profile = await create(env);
  env.DB.afterUpdate = async () => { throw new Error('response lost after durable commit'); };
  const response = await upload(env, profile);
  assert.equal(response.status, 200, await response.clone().text());
  assert.equal((await response.json()).profile.revision, 2);
  assert.equal(env.BUCKET.objects.size, 1);
  assert.equal((await request(env, 'profiles/profile_1/images/race_1')).status, 200);
});

test('temporary old-image cleanup failure retries without reverting a committed profile', async () => {
  const env = fixture(), profile = await create(env);
  const current = (await (await upload(env, profile)).json()).profile;
  env.BUCKET.failDeletes = 1;
  const response = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: current.revision, data: { ...current.data, records: [] } } });
  assert.equal(response.status, 200); assert.equal(env.DB.row('account-a', profile.id).revision, 3); assert.equal(env.BUCKET.objects.size, 0);
});

test('invalid image bytes are rejected before writing data or R2 objects', async () => {
  const env = fixture(), profile = await create(env);
  const response = await upload(env, profile, { bytes: Buffer.from('<svg onload="alert(1)"></svg>'), type: 'image/png' });
  assert.equal(response.status, 415); assert.equal(env.BUCKET.objects.size, 0); assert.equal(env.DB.row('account-a', profile.id).revision, 1);
});

test('record duplicates, invalid dates and unsafe identifiers are rejected server-side', async () => {
  const env = fixture(), profile = await create(env);
  for (const data of [
    { ...emptyData(), records: [race(), race({ id: 'second-copy' })] },
    { ...emptyData(), records: [race({ date: '2026-02-30' })] },
    { ...emptyData(), records: [race({ id: '../outside' })] },
    { ...emptyData(), records: [race({ averageHr: 190, peakHr: 180 })] }
  ]) {
    const response = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: 1, data } });
    assert.ok([400, 409].includes(response.status));
  }
  assert.equal(env.DB.row('account-a', profile.id).revision, 1);
});

test('draft forms and normalized plan/history data round trip without losing partial inputs', async () => {
  const env = fixture(), key = 'xunxu-checkins-v1:half-target-v1:2027-01-01:6300:profile:p';
  const data = { form: { raceDate: '2027-', weeklyKm: '', halfGoalTime: '01:' }, records: [], plans: { [key]: { started: TODAY, checkins: { [TODAY]: true } } }, history: [{ planKey: key, started: TODAY, dates: [TODAY, TODAY] }] };
  const created = await create(env, 'p', 'account-a', data);
  assert.equal(created.data.form.raceDate, '2027-'); assert.equal(created.data.form.weeklyKm, '');
  assert.equal(created.data.plans[key].checkins[TODAY], true); assert.deepEqual(created.data.history[0].dates, [TODAY]);
});

test('100-profile limit is per authenticated account and enforced in the insert statement', async () => {
  const env = fixture();
  for (let index = 0; index < 100; index++) await create(env, 'p_' + index);
  const tooMany = await request(env, 'profiles', { method: 'POST', value: { id: 'p_100', name: '第101份', data: emptyData() } });
  assert.equal(tooMany.status, 409); assert.equal((await tooMany.json()).code, 'profile_limit');
  assert.equal(env.DB.sqlite.prepare('SELECT COUNT(*) AS n FROM xunxu_profiles WHERE owner_id = ?').get('account-a').n, 100);
  await create(env, 'p_100', 'account-b');
});

test('oversized JSON and too many records cannot be stored', async () => {
  const env = fixture(), profile = await create(env);
  const huge = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: 1, data: { ...emptyData(), form: { raceDate: 'x'.repeat(1024 * 1024) } } } });
  assert.equal(huge.status, 413);
  const many = await request(env, 'profiles/profile_1', { method: 'PUT', value: { revision: 1, data: { ...emptyData(), records: Array.from({ length: 101 }, (_, index) => race({ id: 'r_' + index, elapsedSeconds: 3000 + index })) } } });
  assert.equal(many.status, 400); assert.equal(env.DB.row('account-a', profile.id).revision, 1);
});
