const fs = require('node:fs');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const root = path.resolve(__dirname, '..');
const out = path.join(root, 'public/planner');
fs.mkdirSync(out, {recursive:true});
fs.copyFileSync(path.join(root,'index.html'),path.join(out,'index.html'));
for (const name of fs.readdirSync(path.join(root,'src'))) {
  if (/\.(js|css)$/.test(name)) fs.copyFileSync(path.join(root,'src',name),path.join(out,name));
}
execFileSync(process.execPath,[path.join(root,'scripts/vendor-ocr.cjs')],{cwd:root,stdio:'inherit'});
console.log('Prepared cloud planner UI and browser OCR assets.');
